package com.example.assignment1

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.assignment1.databinding.MyListItemBinding
import com.example.assignment1.databinding.MyViewlistItemBinding
import com.example.assignment1.databinding.ViewlistBinding
import com.google.firebase.firestore.ktx.toObject
import com.squareup.picasso.Picasso

class Viewlist : AppCompatActivity() {
    var week: String? = null
    private lateinit var ui: ViewlistBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val weekTxt = intent.getStringExtra("Week")
        week = weekTxt
        ui = ViewlistBinding.inflate(layoutInflater)
        setContentView(ui.root)


        val studentCollection = db.collection("student")
        studentCollection
            .get()
            .addOnSuccessListener { result ->
                items.clear()
                Log.d(FIREBASE_TAG, " All students")
                for (document in result)
                {
                    val student = document.toObject<Student>()
                    student.document_id= document.id
                    Log.d(FIREBASE_TAG, student.toString())
                    items.add(student)

                }
                (ui.viewSummarylist.adapter as Viewlist.StudentAdapter).notifyDataSetChanged()
            }
        ui.viewSummarylist.adapter = StudentAdapter(student = items)
        ui.viewSummarylist.layoutManager = LinearLayoutManager(this)
        ui.btnback.setOnClickListener{ finish()}
        ui.btnHome.setOnClickListener {
            startActivity(
                Intent(this, MainActivity::class.java)

            )
        }

    }
    inner class StudentHolder(var ui: MyViewlistItemBinding) : RecyclerView.ViewHolder(ui.root){
    }

    inner class StudentAdapter(private val student: MutableList<Student>) : RecyclerView.Adapter<StudentHolder>()
    {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Viewlist.StudentHolder{
            val ui = MyViewlistItemBinding.inflate(layoutInflater, parent, false)
            return StudentHolder(ui)


        }



        override fun onBindViewHolder(holder: Viewlist.StudentHolder, position: Int) {
            val std1 = student[position]

            holder.ui.name.text = std1.student_name
            holder.ui.id.text = std1.student_id
            Picasso.get().load(std1.imguri).into(holder.ui.imgView)
            var markscollection = db.collection("student")
          var lotr = markscollection.document("${std1.student_id}")
            var dbcollection = lotr.collection("${std1.student_name}")
            dbcollection.get()
                .addOnSuccessListener {  result ->
                    for (document in result)
                    {
                        var obj = document.toObject<Marks>()
                        if (obj.Week == week)
                        {
                            holder.ui.Attandance.text = obj.attendance.toString()
                            holder.ui.checkpoint1.text = obj.checkpoint1.toString()
                            holder. ui. checkpoint2.text = obj.checkpoint2.toString()
                            holder.ui.checkpoint3.text = obj.checkpoint3.toString()

                            holder. ui.marks.text = obj.score.toString()

                        }


                }


                }
        }

        override fun getItemCount(): Int {
            return student.size
        }

    }
}