package com.example.assignment1

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.widget.ImageView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.net.toUri
import com.example.assignment1.databinding.AddstudentBinding
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

val db = Firebase.firestore
const val FIREBASE_TAG = "FirebaseLogging"
const val REQUEST_IMAGE_CAPTURE = 1




class Addstudent : AppCompatActivity() {

    var imageuri: Uri? = null
    var lotr = Student()


    private lateinit var ui: AddstudentBinding

    lateinit var currentPhotoPath: String
    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        ui = AddstudentBinding.inflate(layoutInflater)
        setContentView(ui.root)

        ui.btnadd2.setOnClickListener {


               lotr.student_id = ui.txtid.getText().toString()
                lotr.student_name = ui.txtname.getText().toString()
            var sid = lotr.student_id
            var name = lotr.student_name

            if (sid != null && name != null) {
                if (sid.isEmpty()) {
                    if (name.isEmpty()) {
                        Snackbar.make(it, "Enter name and student id", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show()
                    }
                    else  {
                        Snackbar.make(it, "Enter student id", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show()
                    }

                }

                else if (name.isEmpty()) {
                        Snackbar.make(it, "Enter student name", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show()


                    }
               else {
                    var count = 0
                    var num = Integer.valueOf(sid)


                    while (num != 0) {
                        num = num?.div(10)
                        count = count + 1
                    }


                    if (imageuri==null) {
                        Snackbar.make(it, "Upload Image", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show()
                    } else {


                        if (count == 6) {
                            uploadImage()

                            if (imageuri!=null) {
                                lotr.imguri = imageuri.toString()




                        }
                        } else {
                            Snackbar.make(it, "Invalid Student ID", Snackbar.LENGTH_LONG)
                                .setAction("Action", null).show()

                        }
                    }
                }


        }

    }
        ui.btncamera.setOnClickListener {
            requestToTakeAPicture()
        }
        ui.btnback1.setOnClickListener {
            finish()
        }
        ui.btnHome1.setOnClickListener {
            startActivity(
                Intent(
                    this, MainActivity::class.java
                )
            )
            finish()
        }

}


    @RequiresApi(Build.VERSION_CODES.M)
    private fun requestToTakeAPicture()
    {
        requestPermissions(
            arrayOf(Manifest.permission.CAMERA),
            REQUEST_IMAGE_CAPTURE
        )
    }


    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        when(requestCode)
        {
            REQUEST_IMAGE_CAPTURE -> {
                if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                    // Permission is granted.
                    takeAPicture()
                } else {
                    Toast.makeText(
                        this,
                        "Cannot access camera, permission denied",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }


    private fun takeAPicture() {
        val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)


        val photoFile: File = createImageFile()!!
        val photoURI: Uri = FileProvider.getUriForFile(
            this,
            "com.example.assignment1",
            photoFile
        )
        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
        startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE)

        imageuri=photoURI

    }




    @Throws(IOException::class)
    private fun createImageFile(): File {

        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
        val storageDir: File = getExternalFilesDir(Environment.DIRECTORY_PICTURES)!!
        return File.createTempFile(
            "JPEG_${timeStamp}_",
            ".jpg",
            storageDir
        ).apply {

            currentPhotoPath = absolutePath
        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

            if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
                setPic(ui.imgstudent)



            }

    }

    private fun setPic(imageView: ImageView) {

        val targetW: Int = imageView.measuredWidth
        val targetH: Int = imageView.measuredHeight

        val bmOptions = BitmapFactory.Options().apply {

            inJustDecodeBounds = true

            BitmapFactory.decodeFile(currentPhotoPath, this)

            val photoW: Int = outWidth
            val photoH: Int = outHeight


            val scaleFactor: Int = Math.max(1, Math.min(photoW / targetW, photoH / targetH))


            inJustDecodeBounds = false
            inSampleSize = scaleFactor
        }
        BitmapFactory.decodeFile(currentPhotoPath, bmOptions)?.also { bitmap ->
            imageView.setImageBitmap(bitmap)
        }
    }

    fun uploadImage() {
        var file = UUID.randomUUID().toString()
        val ref = FirebaseStorage.getInstance().getReference("/images/$file")
            ref.putFile(imageuri!!)
                .addOnSuccessListener {
                    Log.d(
                        FIREBASE_TAG,
                        "Image uploaded sucsessfully: ${it.metadata?.path}"
                    )
                    ref.downloadUrl.addOnSuccessListener {
                        hash(it.toString())
                    }
               }

    }


    private fun hash(uri: String){
        lotr.imguri = uri
        //var data: String? = null
        var details = db.collection("student")
        details.document("${lotr.student_id}").set(hashMapOf(

            "student_id" to lotr.student_id,
            "student_name" to lotr.student_name,
            "imguri" to lotr.imguri
        ))
        var intent = Intent(this, Classlist::class.java)
        startActivity(intent)
        Toast.makeText(this,"Student Added", Toast.LENGTH_SHORT)
            .show()

    }
}
