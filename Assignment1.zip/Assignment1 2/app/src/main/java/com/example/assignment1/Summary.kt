package com.example.assignment1

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.assignment1.databinding.MarkinglistBinding
import com.example.assignment1.databinding.MyListItemBinding
import com.example.assignment1.databinding.MySummarylistItemBinding

import com.example.assignment1.databinding.SummaryBinding
import com.google.firebase.firestore.ktx.toObject
import com.squareup.picasso.Picasso
import java.io.File

class Summary : AppCompatActivity() {
    private lateinit var ui: SummaryBinding
    val items = mutableListOf<Marks>()
    var profileName: String? = null
    var profileID: String? = null
 var averageMK :Int?=0
    var averageAT :Int?=0
    var count :Int?=0
    var size :Int?=0
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)


        val sName = intent.getStringExtra("Name")
        val sId = intent.getStringExtra("ID")
        profileName = sName
        profileID = sId
        ui = SummaryBinding.inflate(layoutInflater)
        setContentView(ui.root)
        ui.btnShare.setOnClickListener {

            var sendIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_SUBJECT, ui.viewSummarylist.toString())
                putExtra(Intent.EXTRA_TEXT, ui.name.text.toString())
                putExtra(Intent.EXTRA_TEXT,ui.id.text.toString())
                putExtra(Intent.EXTRA_TEXT,ui.textView12.text.toString())
                putExtra(Intent.EXTRA_TEXT,ui.textView18.text.toString())
                putExtra(Intent.EXTRA_TEXT,ui.textView9.text.toString())
                putExtra(Intent.EXTRA_TEXT,ui.textView20.text.toString())
                type = "text/plain"
            }
            startActivity(Intent.createChooser(sendIntent, "Share via..."))
        }

ui.name.text= profileName
        ui.id.text = profileID
        val studentCollection = db.collection("student").document("$profileID").collection("$profileName")
        studentCollection
            .get()
            .addOnSuccessListener { result ->
                items.clear()
                Log.d(FIREBASE_TAG, " All students")
                for (document in result) {
                    val student = document.toObject<Marks>()
                    Log.d(FIREBASE_TAG, student.toString())
                    items.add(student)

                }
                (ui.viewSummarylist.adapter as Summary.StudentAdapter).notifyDataSetChanged()
            }
        ui.viewSummarylist.adapter = StudentAdapter(marks = items)
        ui.viewSummarylist.layoutManager = LinearLayoutManager(this)

        ui.btnback.setOnClickListener{ finish()}
        ui.btnHome1.setOnClickListener {
            startActivity(
                Intent(this, MainActivity::class.java)

            )
        }

    }

    inner class StudentHolder(var ui: MySummarylistItemBinding) : RecyclerView.ViewHolder(ui.root) {
    }

    inner class StudentAdapter(private val marks: MutableList<Marks>) :
        RecyclerView.Adapter<StudentHolder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Summary.StudentHolder {
            val ui = MySummarylistItemBinding.inflate(layoutInflater, parent, false)
            return StudentHolder(ui)


        }


        override fun getItemCount(): Int {
            size=marks.size
        return marks.size
        }

        override fun onBindViewHolder(holder: StudentHolder, position: Int) {
count= count?.plus(1)
            var mark = marks[position]
            Log.d(FIREBASE_TAG,mark.Week.toString())
            holder.ui.textView17.text = mark.Week
           holder.ui.textView15.text=mark.attendance
            holder.ui.checkpoint1.text=mark.checkpoint1
            holder.ui.checkpoint2.text=mark.checkpoint2
            holder.ui.checkpoint3.text=mark.checkpoint3
            holder.ui.checkpoint4.text=mark.checkpoint4
            holder.ui.textView16.text=mark.score
            averageAT = averageAT?.plus(Integer.valueOf(mark.attendance))
            averageMK = averageMK?.plus(Integer.valueOf(mark.score))
            if (size==count)
            {
                averageAT= averageAT?.div(size!!)
                averageMK= averageMK?.div(size!!)
                ui.textView18.text = averageAT.toString()
                ui.textView20.text = averageMK.toString()
            }

        }
    }
}
