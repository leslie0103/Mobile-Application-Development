package com.example.assignment1



class Marks(
    var studentname: String? = null,
    var studentid: String? = null,
    var Week: String? = null,
    var attendance: String? = null,
    var checkpoint1: String? = null,
    var checkpoint2: String? = null,
    var checkpoint3: String? = null,
    var checkpoint4: String? = null,
    var score: String? = null
)
