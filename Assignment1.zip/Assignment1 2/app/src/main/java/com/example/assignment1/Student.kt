package com.example.assignment1

import android.net.Uri
import java.io.Serializable

class Student {
    var document_id: String? = null
    var student_name: String? = null
    var student_id: String? = null
    var imguri: String? = null

}


