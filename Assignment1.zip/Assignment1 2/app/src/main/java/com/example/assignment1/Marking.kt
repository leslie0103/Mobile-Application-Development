package com.example.assignment1

import android.R
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.View.INVISIBLE
import android.view.View.VISIBLE
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity
import com.example.assignment1.databinding.MarkingBinding
import com.google.firebase.firestore.ktx.toObject

class Marking: AppCompatActivity() {
    private lateinit var ui:MarkingBinding
    val items = mutableListOf<Student>()
    var mySpinnerItems = arrayOf("Week1", "Week2", "Week3", "Week4","Week5", "Week6", "Week7", "Week8")
    var mySpinnerItems1 = arrayOf("1", "2", "3","4")
    var mySpinnerItems2 = arrayOf("Score","Grade level (HD/DN/CR/PP/NN)","Grade Level (A/B/C/D/E/F)")
    var selectWeek: String? = null
    var selectCheckpoint: String? = null
    var selectGrade: String? = null
    var count=0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = MarkingBinding.inflate(layoutInflater)
        setContentView(ui.root)
        val studentCollection = db.collection("student")
        studentCollection
            .get()
            .addOnSuccessListener { result ->
                items.clear()
                Log.d(FIREBASE_TAG, " All students")
                for (document in result) {
                    val student = document.toObject<Student>()
                    Log.d(FIREBASE_TAG, student.toString())
                    items.add(student)

                }
                ui.button2.setOnClickListener {
                    var intent = Intent(this, Viewlist::class.java)
                    intent.putExtra("Week", selectWeek)
                    startActivity(intent)
                }
                ui.buttonhome.setOnClickListener {
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                    finish()
                }
                ui.buttonback.setOnClickListener {
                    finish()
                }


                ui.spinner.adapter = ArrayAdapter<String>(
                    this,
                    R.layout.simple_spinner_dropdown_item,
                    mySpinnerItems
                )
                ui.spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(
                        parent: AdapterView<*>,
                        view: View,
                        position: Int,
                        id: Long
                    ) {
                        val selectedItem = parent.getItemAtPosition(position).toString()
                        Log.d("TAG", selectedItem)
                        selectWeek = selectedItem

                        for (students in items) {

                           count=0
                            val power = db.collection("student").document("${students.student_id}")
                                .collection("${students.student_name}")
                            power.get()
                                .addOnSuccessListener { result ->
                                    for (document in result) {
                                        var obj = document.toObject<Marks>()
                                        if (obj.Week == selectedItem) {
                                            count == 1
                                            ui.spinner2.visibility = INVISIBLE
                                            ui.spinner3.visibility = INVISIBLE
                                            ui.textView3.visibility = INVISIBLE
                                            ui.textView4.visibility = INVISIBLE
                                            ui.button.visibility = INVISIBLE
                                            Log.d(FIREBASE_TAG,"{obj.score.toString()}")
                                        }
                                    }
                                } }

                        if (count==0)
                        {
                            ui.spinner2.visibility = VISIBLE
                            ui.spinner3.visibility = VISIBLE
                            ui.textView3.visibility = VISIBLE
                            ui.textView4.visibility = VISIBLE
                            ui.button.visibility = VISIBLE
                        }

                    } // to close the onItemSelected

                    override fun onNothingSelected(parent: AdapterView<*>) {
                    }
                }
                ui.spinner2.adapter = ArrayAdapter<String>(
                    this,
                    R.layout.simple_spinner_dropdown_item,
                    mySpinnerItems1
                )
                ui.spinner2.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(
                        parent: AdapterView<*>,
                        view: View,
                        position: Int,
                        id: Long
                    ) {
                        val selectedItem = parent.getItemAtPosition(position).toString()
                        selectCheckpoint = selectedItem
                        Log.d("TAG", selectedItem)

                    } // to close the onItemSelected

                    override fun onNothingSelected(parent: AdapterView<*>) {
                    }
                }
                ui.spinner3.adapter = ArrayAdapter<String>(
                    this,
                    R.layout.simple_spinner_dropdown_item,
                    mySpinnerItems2
                )

                ui.spinner3.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(
                        parent: AdapterView<*>,
                        view: View,
                        position: Int,
                        id: Long
                    ) {
                        val selectedItem = parent.getItemAtPosition(position).toString()
                        selectGrade = selectedItem
                    } // to close the onItemSelected

                    override fun onNothingSelected(parent: AdapterView<*>) {
                    }
                }
                ui.button.setOnClickListener {
                    Log.d(FIREBASE_TAG, selectWeek.toString())

                        var intent = Intent(this, Markinglist::class.java)
                        intent.putExtra("Week", selectWeek)
                        intent.putExtra("Checkpoint", selectCheckpoint)
                        intent.putExtra("Grade", selectGrade)
                        startActivity(intent)


                }


            }
    }
    }

