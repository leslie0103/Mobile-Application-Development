package com.example.assignment1

import android.R
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.View.VISIBLE
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doOnTextChanged
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.assignment1.databinding.*
import com.google.firebase.firestore.ktx.toObject
import com.squareup.picasso.Picasso

class Markinglist : AppCompatActivity() {
    var Checkpoint: Double? = null
    val items = mutableListOf<Student>()
    val score = mutableListOf<Marks>()
    var mySpinnerItems = arrayOf("Select Grade","HD+","HD", "DN", "CR","PP", "NN")
    var mySpinnerItems1 = arrayOf("Select Grade","A","B","C","D","E","F" )
    var gradeLevel: String? = "0"



    private lateinit var ui: MarkinglistBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val weekTxt = intent.getStringExtra("Week")
        val checkpointTxt = intent.getStringExtra("Checkpoint")
        val grade = intent.getStringExtra("Grade")
        gradeLevel = grade
        checkpointTxt?.toDouble().also { Checkpoint = it }



        ui = MarkinglistBinding.inflate(layoutInflater)
        setContentView(ui.root)
        ui.btnback.setOnClickListener {
           finish()
        }

        ui.btnhome.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }

        val studentCollection = db.collection("student")
        studentCollection
            .get()
            .addOnSuccessListener { result ->
                items.clear()
                Log.d(FIREBASE_TAG, " All students")
                for (document in result) {
                    val student = document.toObject<Student>()
                    Log.d(FIREBASE_TAG, student.toString())
                    items.add(student)

                }
                (ui.viewSummarylist.adapter as Markinglist.StudentAdapter).notifyDataSetChanged()
            }
        ui.viewSummarylist.adapter = StudentAdapter(students = items)
        ui.viewSummarylist.layoutManager = LinearLayoutManager(this)
        ui.btnadd.setOnClickListener{
            for (marks in score) {
                studentCollection.document("${marks.studentid}").collection("${marks.studentname}").document("${weekTxt}")
                    .set(hashMapOf(
                        "Week" to weekTxt,
                        "attendance" to marks.attendance,
                        "checkpoint1" to marks.checkpoint1,
                        "checkpoint2" to marks.checkpoint2,

                        "checkpoint3" to marks.checkpoint3,
                        "checkpoint4" to marks. checkpoint4,
                        "score" to marks.score
                    ))

            }
Toast.makeText(this, "Saved Successfully", Toast.LENGTH_SHORT)
    .show()        }


    }

    inner class StudentHolder(var ui: MyMarkslistItemsBinding) : RecyclerView.ViewHolder(ui.root) {
    }

    inner class StudentAdapter(private val students: MutableList<Student>) :
        RecyclerView.Adapter<StudentHolder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Markinglist.StudentHolder {
            val ui = MyMarkslistItemsBinding.inflate(layoutInflater, parent, false)
            return StudentHolder(ui)


        }



        override fun onBindViewHolder(holder: StudentHolder, position: Int) {
            val std = students[position]
            var mark = Marks (
                studentid = std.student_id,
                studentname = std.student_name,
                attendance = "0",
                checkpoint1 = "0",
                checkpoint2 = "0",
                checkpoint3 = "0",
                checkpoint4 = "0",
                score = "0"

                    )
            //var checked: Int? = null
            var count: Double? = 0.0
            var count1: Double? = 0.0


            Picasso.get().load(std.imguri).into(holder.ui.imgView)
            holder.ui.name.text = std.student_name
            holder.ui.id.text = std.student_id
            holder.ui.checkBox6.setOnClickListener {


                if (holder.ui.checkBox6.isChecked) {
                    Log.d(FIREBASE_TAG, std.student_id.toString())

                    for (marks in score) {
                        if (marks.studentid == std.student_id) {
                            marks.attendance = "100"
                        }
                    }
                } else {
                    for (marks in score) {
                        if (marks.studentid == std.student_id) {
                            marks.attendance = "0"
                        }
                    }
                }
            }


            if (Checkpoint == 1.0) {
                holder.ui.checkBox1.setVisibility(VISIBLE)
                count = 100/ Checkpoint!!
                Log.d("TAG", count.toString())

            }
            if (Checkpoint == 2.0) {
                holder.ui.checkBox1.setVisibility(VISIBLE)
                holder.ui.checkBox2.setVisibility(VISIBLE)
                count = 100/ Checkpoint!!
                Log.d("TAG", count.toString())
            }
            if (Checkpoint == 3.0) {
                holder.ui.checkBox1.setVisibility(VISIBLE)
                holder.ui.checkBox2.setVisibility(VISIBLE)
                holder.ui.checkBox3.setVisibility(VISIBLE)
                count1 = 100/ Checkpoint!!
                count = Math.round(count1 * 10.0)/ 10.0
                Log.d("TAG", count.toString())
            }
            if (Checkpoint == 4.0) {
                holder.ui.checkBox1.setVisibility(VISIBLE)
                holder.ui.checkBox2.setVisibility(VISIBLE)
                holder.ui.checkBox3.setVisibility(VISIBLE)
                holder.ui.checkBox4.setVisibility(VISIBLE)
                count = 100/ Checkpoint!!

                Log.d("TAG", count.toString())
            }
            holder.ui.checkBox1.setOnClickListener {
                if (holder.ui.checkBox1.isChecked) {
                    for (marks in score) {
                        if (marks.studentid == std.student_id) {
                            if (Checkpoint == 1.0)
                            {
                                marks.checkpoint1 = count.toString()
                            }
                            if (Checkpoint == 2.0)
                            {
                                marks.checkpoint1 = count.toString()
                            }
                            if (Checkpoint == 3.0)
                            {
                                marks.checkpoint1 = count.toString()
                            }
                            if (Checkpoint == 4.0)
                            {
                                marks.checkpoint1 = count.toString()
                            }

                        }
                    }
                } else {
                    for (marks in score) {
                        if (marks.studentid == std.student_id) {
                            marks.checkpoint1="0"
                        }
                    }
                }
            }

            holder.ui.checkBox2.setOnClickListener {
                if (holder.ui.checkBox2.isChecked) {
                    for (marks in score) {
                        if (marks.studentid == std.student_id) {

                            if (Checkpoint == 2.0)
                            {
                                marks.checkpoint2 = count.toString()
                            }
                            if (Checkpoint == 3.0)
                            {
                                marks.checkpoint2 = count.toString()
                            }
                            if (Checkpoint == 4.0)
                            {
                                marks.checkpoint2 = count.toString()
                            }

                        }
                    }
                } else {
                    for (marks in score) {
                        if (marks.studentid == std.student_id) {
                            marks.checkpoint2="0"
                        }
                    }
                }
            }

            holder.ui.checkBox3.setOnClickListener {
                if (holder.ui.checkBox3.isChecked) {
                    for (marks in score) {
                        if (marks.studentid == std.student_id) {

                            if (Checkpoint == 3.0)

                            {

                                marks.checkpoint3 = count.toString()
                            }
                            if (Checkpoint == 4.0)
                            {
                                marks.checkpoint3 = count.toString()
                            }

                        }
                    }
                } else {
                    for (marks in score) {
                        if (marks.studentid == std.student_id) {
                            marks.checkpoint3="0"
                        }
                    }
                }
            }
            holder.ui.checkBox4.setOnClickListener {
                if (holder.ui.checkBox4.isChecked) {
                    for (marks in score) {
                        if (marks.studentid == std.student_id) {
                            if (Checkpoint == 4.0)
                            {
                                marks.checkpoint4 = count.toString()
                            }

                        }
                    }
                } else {
                    for (marks in score) {
                        if (marks.studentid == std.student_id) {
                            marks.checkpoint4="0"
                        }
                    }
                }
            }
if (gradeLevel == "Score")
{
    holder.ui.editTextTextPersonName6.setVisibility(VISIBLE)
}
            if (gradeLevel == "Grade level (HD/DN/CR/PP/NN)")
            {
                holder.ui.spinner6.setVisibility(VISIBLE)
            }
            if (gradeLevel == "Grade Level (A/B/C/D/E/F)")
            {
                holder.ui.spinner7.setVisibility(VISIBLE)
            }

            holder.ui.spinner6.adapter = ArrayAdapter<String>(
                this@Markinglist,
                R.layout.simple_spinner_dropdown_item,
                mySpinnerItems
            )
            holder.ui.spinner6.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                    val selectedItem = parent.getItemAtPosition(position).toString()
                    if (selectedItem == "HD+")
                    {
                       mark.score = "100"
                    }
                    if (selectedItem == "HD")
                    {
                        mark.score = "80"
                    }
                    if (selectedItem == "DN")
                    {
                        mark.score = "70"
                    }
                    if (selectedItem == "CR")
                    {
                        mark.score = "60"
                    }
                    if (selectedItem == "PP")
                    {
                        mark.score = "50"
                    }
                    if (selectedItem == "NN")
                    {
                        mark.score = "0"
                    }
                } // to close the onItemSelected

                override fun onNothingSelected(parent: AdapterView<*>) {
                }
            }
            holder.ui.spinner7.adapter = ArrayAdapter<String>(
                this@Markinglist,
                R.layout.simple_spinner_dropdown_item,
                mySpinnerItems1
            )
            holder.ui.spinner7.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                    val selectedItem = parent.getItemAtPosition(position).toString()

                    if (selectedItem == "A")
                    {
                        mark.score = "100"
                    }
                    if (selectedItem == "B")
                    {
                        mark.score = "80"
                    }
                    if (selectedItem == "C")
                    {
                        mark.score = "70"
                    }
                    if (selectedItem == "D")
                    {
                        mark.score = "60"
                    }
                    if (selectedItem == "E")
                    {
                        mark.score = "50"
                    }
                    if (selectedItem == "F")
                    {
                        mark.score = "0"
                    }
                } // to close the onItemSelected

                override fun onNothingSelected(parent: AdapterView<*>) {
                }
            }

            holder.ui.editTextTextPersonName6.doOnTextChanged{text, start, before, count ->
            for (marks in score)
            {
                if(marks.studentid == std.student_id)
                {
                    mark.score = holder.ui.editTextTextPersonName6.getText().toString()
                }

            }
            }
            score.add(mark)

        }

        override fun getItemCount(): Int {
            return students.size
        }

    }
}