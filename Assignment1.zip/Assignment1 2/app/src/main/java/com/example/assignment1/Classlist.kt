package com.example.assignment1

import android.app.usage.UsageEvents
import android.content.Intent
import android.media.Image
import android.os.Bundle
import android.util.Log
import android.view.DragEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.assignment1.databinding.ActivityMainBinding
import com.example.assignment1.databinding.ClasslistBinding
import com.example.assignment1.databinding.MyListItemBinding
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.firestore.ktx.toObject
import com.squareup.picasso.Picasso

val items = mutableListOf<Student>()




class Classlist : AppCompatActivity() {

    private lateinit var ui: ClasslistBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        ui = ClasslistBinding.inflate(layoutInflater)
        setContentView(ui.root)

        ui.btnback.setOnClickListener{ finish()}
        ui.btnHome.setOnClickListener {
            startActivity(
                Intent(this, MainActivity::class.java)

            )
        }




        ui.btnadd.setOnClickListener {
            var intent = Intent(this, Addstudent::class.java)
            startActivity(intent)
        }

        val studentCollection = db.collection("student")
        studentCollection
            .get()
            .addOnSuccessListener { result ->
                items.clear()
                Log.d(FIREBASE_TAG, " All students")
                for (document in result)
                {
                    val student = document.toObject<Student>()
                    student.document_id= document.id
                    Log.d(FIREBASE_TAG, student.toString())
                    items.add(student)

                }
                (ui.viewClasslist.adapter as StudentAdapter).notifyDataSetChanged()
            }
        ui.viewClasslist.adapter = StudentAdapter(students = items)
        ui.viewClasslist.layoutManager = LinearLayoutManager(this)

    }
    inner class StudentHolder(var ui: MyListItemBinding) : RecyclerView.ViewHolder(ui.root){
    }

    inner class StudentAdapter(private val students: MutableList<Student>) : RecyclerView.Adapter<StudentHolder>()
    {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Classlist.StudentHolder{
            val ui = MyListItemBinding.inflate(layoutInflater, parent, false)
            return StudentHolder(ui)


        }



        override fun onBindViewHolder(holder: Classlist.StudentHolder, position: Int) {
            val std = students[position]
            holder.ui.name.text =  std.student_name
            holder.ui.id.text = std.student_id
            Picasso.get().load(std.imguri).into(holder.ui.imgView)
            holder.ui.editButton.setOnClickListener {

            }
            holder.ui.deleteButton.setOnClickListener { deleteStd(it, position) }
            holder.ui.sumButton.setOnClickListener{
                var intent = Intent(this@Classlist, Summary::class.java)
                intent.putExtra("Name", std.student_name)
                intent.putExtra("ID", std.student_id)

                startActivity(intent)
            }



        }

        private fun deleteStd(it: View?, position: Int)
        {
            val std = students[position]
            var name = std.student_name
            //var ssid = std.student_id
            var did=std.student_id
            if (name != null) {
                Log.d(FIREBASE_TAG, name)
            }
            var builder = AlertDialog.Builder(this@Classlist)
            builder.setTitle("Confirm Delete")
            builder.setMessage("Are you sure you want to delete this")
            builder.setPositiveButton("Yes", { dialog,_ ->

                db.collection("student")?.document("$did")
                    .delete()
                    .addOnSuccessListener { Log.d(FIREBASE_TAG, "DocumentSnapshot successfully deleted!") }

                    .addOnFailureListener { e -> Log.w(FIREBASE_TAG, "Error deleting document", e) }


                db.collection("student").get()
                    .addOnSuccessListener { result ->
                        for (document in result) {
                            var obj = document.toObject<Marks>()

                            db.collection("student")?.document("$did").collection("$name")
                                .document("${obj.Week}")
                                .delete()
                        }
                    }

                        dialog.cancel()
                if (it != null) {
                    Snackbar.make(it, "Student Deleted", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show()

                }
                var intent = Intent(this@Classlist, Classlist::class.java)
                startActivity(intent)
                Toast.makeText(this@Classlist,"Student Deleted", Toast.LENGTH_SHORT)
                    .show()
            }
                )
            builder.setNegativeButton("No", { dialog, _ ->
                dialog.cancel()
        })
        var alert =builder.create()
            alert.show()
        }


        override fun getItemCount(): Int {

            return students.size
        }


    }


}