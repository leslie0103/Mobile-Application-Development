package com.example.assignment1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.assignment1.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity()

{
    private lateinit var ui : ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        ui = ActivityMainBinding.inflate(layoutInflater)
        setContentView(ui.root)

        ui.btnclass.setOnClickListener {
            var intent = Intent(this, Classlist::class.java)
            startActivity(intent)
        }


}}