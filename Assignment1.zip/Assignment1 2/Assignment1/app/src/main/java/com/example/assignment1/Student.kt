package com.example.assignment1

import android.net.Uri

class Student (
   // var id: Int? = null,
    //var ruri: String? = null,
    var imguri: String? = null,
    var student_name: String? = null,
    var student_id: String? = null


)
