package com.example.assignment1

import android.content.Intent
import android.media.Image
import android.os.Bundle
import android.util.Log
import android.view.ViewGroup
import android.widget.ImageView

import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.assignment1.databinding.ActivityMainBinding
import com.example.assignment1.databinding.ClasslistBinding
import com.example.assignment1.databinding.MyListItemBinding
import com.google.firebase.firestore.ktx.toObject
import com.squareup.picasso.Picasso

val items = mutableListOf<Student>()


class Classlist : AppCompatActivity() {

    private lateinit var ui: ClasslistBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        ui = ClasslistBinding.inflate(layoutInflater)
        setContentView(ui.root)



        ui.btnadd.setOnClickListener {
            var intent = Intent(this, Addstudent::class.java)
            startActivity(intent)
        }

        val studentCollection = db.collection("student")
        studentCollection
            .get()
            .addOnSuccessListener { result ->
                items.clear()
                Log.d(FIREBASE_TAG, " All students")
                for (document in result)
                {
                    val student = document.toObject<Student>()
                   // student.student_id= document.id
                    Log.d(FIREBASE_TAG, student.toString())
                    items.add(student)

                }
                (ui.viewClasslist.adapter as StudentAdapter).notifyDataSetChanged()
            }
        ui.viewClasslist.adapter = StudentAdapter(students = items)
        ui.viewClasslist.layoutManager = LinearLayoutManager(this)
    }
    inner class StudentHolder(var ui: MyListItemBinding) : RecyclerView.ViewHolder(ui.root){}

    inner class StudentAdapter(private val students: MutableList<Student>) : RecyclerView.Adapter<StudentHolder>()
    {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Classlist.StudentHolder{
            val ui = MyListItemBinding.inflate(layoutInflater, parent, false)
            return StudentHolder(ui)

        }
        override fun onBindViewHolder(holder: Classlist.StudentHolder, position: Int) {
            val movie = students[position]
            holder.ui.txtName.text =  movie.student_name
            holder.ui.textid.text = movie.student_id
            Picasso.get().load(movie.imguri).into(holder.ui.imgView)

        }

        override fun getItemCount(): Int {

            return students.size
        }
    }


}