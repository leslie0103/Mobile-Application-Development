package com.example.assignment1

class Attendance {
}