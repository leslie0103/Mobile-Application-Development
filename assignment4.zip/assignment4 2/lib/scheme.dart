import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
class scheme
{

  String week;

  String marking;


  scheme({ this.week, this.marking});
scheme.fromJson(Map<String, dynamic> json)
      :
        week = json['week'],
        marking = json['marking'];


  Map<String, dynamic> toJson() =>
      {
        'week': week,
        'marking': marking,

      };

}