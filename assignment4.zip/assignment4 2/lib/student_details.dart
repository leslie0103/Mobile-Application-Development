import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'student.dart';
class StudentDetails extends StatefulWidget {

  final String id;



  const StudentDetails({Key key, this.id}) : super(key: key);


  @override
  _StudentDetailsState createState() => _StudentDetailsState();
}

class _StudentDetailsState extends State<StudentDetails> {
  final _formKey = GlobalKey<FormState>();
  final stdnameController = TextEditingController();
  final stdidController = TextEditingController();



  @override
  Widget build(BuildContext context) {

    var student = Provider.of<StudentModel>(context, listen:false).get(widget.id);
    var adding = student == null;
    if (!adding) {
      stdnameController.text = student.stdname;
      stdidController.text = student.stdid.toString();
    }

    return Scaffold(

        appBar: AppBar(
          title: Text("Add/Edit Student Details"),
        ),
        body: Padding(
            padding: EdgeInsets.all(8),
            child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[

                  Form(
                    key: _formKey,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        children: <Widget>[
                          TextFormField(
                            decoration: InputDecoration(labelText: "Student Name"),
                            controller: stdnameController,
                            autofocus: true,
                          ),
                          TextFormField(
                            decoration: InputDecoration(labelText: "Student ID"),
                            controller: stdidController,
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: ElevatedButton.icon(onPressed: () {
                              if (_formKey.currentState.validate())
                              {
                                if (adding)
                                {
                                  student = Student();
                                }
                                 //good code would validate these
                                student.stdname = stdnameController.text;
                                student.stdid = int.parse(stdidController.text);

                                //update the model
                                if (adding)
                                  Provider.of<StudentModel>(context, listen: false).add(student);

                              else
                                Provider.of<StudentModel>(context, listen:false).update(widget.id, student);


                                //return to previous screen
                                Navigator.pop(context);
                              }
                            },
                                icon: Icon(Icons.save), label: Text("Save Values")),
                          )
                        ],
                      ),
                    ),
                  )
                ]
            )
        )
    );
  }
}



