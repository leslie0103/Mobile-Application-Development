import 'dart:async';

import 'package:assignment4/SummaryDetails.dart';
import 'package:assignment4/scheme.dart';
import 'package:assignment4/student.dart';
import 'package:assignment4/student_details.dart';
import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final Future<FirebaseApp> _initialization = Firebase.initializeApp();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
        future: _initialization,
        builder: (context, snapshot) //this functio is called every time the "future" updates
        {
          if (snapshot.hasError) {
            return FullScreenText(text:"Something went wrong");
          }
          if (snapshot.connectionState == ConnectionState.done)
            {

            return ChangeNotifierProvider(
      create: (context) => StudentModel(),
      child: MaterialApp(
        title: 'Assignment4',
        theme: ThemeData(
          primarySwatch: Colors.blueGrey,
        ),
        home: MyHomePage(title: 'Student List'),
      ),
    );
  }
          return FullScreenText(text:"Loading");
        },
    );
  }
}
class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    return Consumer<StudentModel>(
        builder:buildScaffold

    );
  }

  Scaffold buildScaffold(BuildContext context, StudentModel studentModel, _) {


    return Scaffold(
      key: _scaffoldKey,
    appBar: AppBar(
      title: Text(widget.title),
    ),
      floatingActionButton:
      Wrap(
       // direction: Axis.horizontal,

        children: <Widget> [
          Container(

          margin: EdgeInsets.all(10),
        child: FloatingActionButton(
        onPressed: () {
          showDialog(context: context, builder: (context) {
            return StudentDetails();
          });

        },
          heroTag: "btn1",
          child: Icon(Icons.person_add_alt_1),
    )
          ),
         Container(
             margin: EdgeInsets.all(10),
              child: FloatingActionButton(
                onPressed: () {

                  showDialog(context: context, builder: (context) {
                    return MarkScheme();
                  });
                },
                heroTag: "btn2",
                child: Icon(Icons.add_moderator),
              )
          ),
      ]

      ),




    body: Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          if (studentModel.loading) CircularProgressIndicator() else Expanded(
            child: ListView.builder(
                itemBuilder: (_, index) {
                  var student = studentModel.items[index];
                  return Dismissible(
                    child:ListTile(
                    title:Text(student.stdname),
                    subtitle: Text(student.stdid.toString()),
                    leading: student.image != null ? Image.network(student.image) : null,
                      trailing: ElevatedButton.icon(onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) { return SummaryDetails(id:student.id);}));
                      },
                        icon: Icon(Icons.article_outlined), label: Text("SUMMARY")),
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) { return StudentDetails(id:student.id);}));
                    },

                  ),
                    background: Container(
                      color: Colors.red,
                    ),
                    key: ValueKey<int>(index),
                    onDismissed: (DismissDirection direction) {
                      setState(() {
                        Provider.of<StudentModel>(context, listen: false)

                            .delete(student.id);
                        _showSnackBar();
                        studentModel.items.removeAt(index);
                      });
                    },
                  );
                },
                itemCount:studentModel.items.length

            ),
          )

          //YOUR UI HERE


        ],
      ),
    ),
  );
  }
  void _showSnackBar() {
    _scaffoldKey.currentState.showSnackBar(
        SnackBar(
          content: Text('Student Deleted'),
        )
    );
  }
}

class MarkScheme extends StatefulWidget {
  @override
  _MyMarkSchemeState createState() => _MyMarkSchemeState();
}

class _MyMarkSchemeState extends State<MarkScheme> {
  String _chosenWeek;
  String _chosenScheme;
  int p = 0;
  bool isVisible = true;
  bool dbvalue =false;

  final List<scheme> items = [];

  CollectionReference SchemeCollection = FirebaseFirestore.instance.collection('scheme');
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: Text("Marking"),
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: () {
if (_chosenWeek != null && _chosenScheme!=null && dbvalue == false ) {
  add();
  log("$_chosenWeek");
  log("$_chosenScheme");
  showDialog(context: context, builder: (context) {
    return Marking(title: _chosenWeek,text: _chosenScheme);
  });
}
  if (_chosenWeek != null && _chosenScheme!=null && dbvalue == true ) {
    log("$_chosenWeek");
    log("$_chosenScheme");
    showDialog(context: context, builder: (context) {
      return Marking(title: _chosenWeek,text: _chosenScheme);
    });
}
  if(_chosenWeek == null || _chosenScheme==null)
    {
      _showDialog(context);

    }

        },
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[

            //YOUR UI HERE
            DropdownButton<String>(
              focusColor:Colors.white,
              value: _chosenWeek,
              //elevation: 5,
              style: TextStyle(color: Colors.white),
              iconEnabledColor:Colors.black,
              items: <String>[
                'Week01',
                'Week02',
                'Week03',
                'Week04',
                'Week05',
                'Week06',
                'Week07',
                'Week08',
                'Week09',
                'Week10',
              ].map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value,style:TextStyle(color:Colors.black),),
                );
              }).toList(),
              hint:Text(
                "Please choose a WEEK",
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 14,
                    fontWeight: FontWeight.w500),
              ),
              onChanged: (String value)  async {

                setState(()   {


                  _chosenWeek= value;

                });
                p=  await check(_chosenWeek) ;

             log("$p");
              },
            ),

Visibility(
 visible: isVisible,

  child: DropdownButton<String>(
      focusColor: Colors.white,
      value: _chosenScheme,
      //elevation: 5,
      style: TextStyle(color: Colors.white),
      iconEnabledColor: Colors.black,
      items: <String>[
        'Score',
        'Grade level (HD/DN/CR/PP/NN)',
        'Grade Level (A/B/C/D/E/F)',
        'Attendance',
        'Checkpoints',

      ].map<DropdownMenuItem<String>>((String value) {
        return DropdownMenuItem<String>(
          value: value,
          child: Text(value, style: TextStyle(color: Colors.black),),
        );
      }).toList(),
      hint: Text(
        "Please choose a Marking Scheme",
        style: TextStyle(
            color: Colors.black,
            fontSize: 14,
            fontWeight: FontWeight.w500),
      ),
      onChanged: (String value) {
        setState(() {
          _chosenScheme = value;
        }


        );
      },
    ),
),

          ],
        ),
      ),
    );
  }

  // ignore: missing_return
  Future<int> check(String c)
  async {
int j =0;
    var querySnapshot =  await SchemeCollection.orderBy("week").get();
    querySnapshot.docs.forEach((doc) {
      //note not using the add(Movie item) function, because we don't want to add them to the db
      var student = scheme.fromJson(doc.data());
     if (student.week== c)
       {
      j=1;

_chosenScheme= student.marking;
       }
    });
setState(()   {


  _chosenWeek= c;
  if  (j==0)
  {
    //  p= 0;
    dbvalue=false;
    isVisible= true;
    return 0;
  }

  if (j==1)
  { isVisible=false;
  dbvalue=true;
    return 1;
  }
});


  }

  Future<void>  add ()
 async {
   Map<String, dynamic> toJson() =>
       {
         'week': _chosenWeek,
         'marking': _chosenScheme,

       };

   await SchemeCollection.add(toJson());


 }
  void _showDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: new Text("Alert!!"),
          content: new Text("Please select the required field"),
          actions: <Widget>[
            new FlatButton(
              child: new Text("OK"),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

}
class Marking extends StatefulWidget {

final String title;
final String text;


  const Marking({Key key, this.title, this.text}) : super(key: key);

  @override
  _MyMarkingState createState() => _MyMarkingState();

}

class _MyMarkingState extends State<Marking> {
  int resultweek;
  String _gradeWeek;
 String _gradesWeek;
  String _gradeAttendence;
  String _gradeCheckpoints;
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  CollectionReference studentsCollection = FirebaseFirestore.instance
      .collection('students');

  @override
  Widget build(BuildContext context) {
    return Consumer<StudentModel>(
        builder: buildScaffold

    );
  }

  Scaffold buildScaffold(BuildContext context, StudentModel studentModel, _) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[

            //YOUR UI HERE
            if (studentModel.loading) CircularProgressIndicator() else
              Expanded(
                child: ListView.builder(
                    itemBuilder: (_, index) {
                      var student = studentModel.items[index];

                      if (widget.title == "Week01") {
                        resultweek = student.Week01;
                      }
                      if (widget.title == "Week02") {
                        resultweek = student.Week02;
                        log("build $resultweek");
                      }
                      if (widget.title == "Week03") {
                        resultweek = student.Week03;
                      }
                      if (widget.title == "Week04") {
                        resultweek = student.Week04;
                      }
                      if (widget.title == "Week05") {
                        resultweek = student.Week05;
                      }
                      if (widget.title == "Week06") {
                        resultweek = student.Week06;
                      }
                      if (widget.title == "Week07") {
                        resultweek = student.Week07;
                      }
                      if (widget.title == "Week08") {
                        resultweek = student.Week08;
                      }
                      if (widget.title == "Week09") {
                        resultweek = student.Week09;
                      }
                      if (widget.title == "Week10") {
                        resultweek = student.Week10;
                      }
                      return ListTile(
                        title: Text(student.stdname),
                        subtitle: Text("${student.stdid
                            .toString()} \nScore:- $resultweek"),
                        isThreeLine: true,

                        leading: student.image != null ? Image.network(
                            student.image) : null,
                        trailing: ElevatedButton.icon(onPressed: () {
                          if (widget.text == "Score") {
                            TextEditingController _textFieldController = TextEditingController();
                            String num;
                            showDialog(
                              context: context,
                              builder: (BuildContext context) {
                                return AlertDialog(
                                  title: new Text("SCORE"),

                                  content: TextField(
                                    onChanged: (value) {
                                      setState(() {
                                        num = value;
                                      });
                                    },
                                    controller: _textFieldController,
                                    decoration: InputDecoration(
                                        hintText: "Enter score between 0-100"),
                                  ),

                                  actions: <Widget>[
                                    TextButton(
                                      onPressed: () =>
                                          Navigator.pop(context, 'Cancel'),
                                      child: const Text('Cancel'),
                                    ),
                                    new FlatButton(
                                      child: new Text("OK"),
                                      onPressed: () {
                                        int number;
                                        number = int.parse(num.toString());
                                       if (number == null)
                                         {
                                           _showSnackBar();
                                         }

                                        if (number >= 0 && number <= 100) {
                                          setState(() {
                                            resultweek= number;
                                          });

                                          add(student.id);
                                        }

                                        else {
                                          _showSnackBar();
                                        }
                                        Navigator.pop(context);
                                      },
                                    ),
                                  ],
                                );
                              },
                            );
                          }


                          if (widget.text == "Grade level (HD/DN/CR/PP/NN)") {



                            showDialog(
                              context: context,
                              builder: (BuildContext context) {
                                return StatefulBuilder(builder: (context,setState)
                                {
                                  return AlertDialog(

                                    title: new Text("SCORE"),

                                    content: DropdownButton<String>(
                                      focusColor: Colors.white,
                                      value: _gradeWeek,
                                      //elevation: 5,
                                      style: TextStyle(color: Colors.white),
                                      iconEnabledColor: Colors.black,
                                      items: <String>[
                                        'Choose a Grade Level (HD+/HD/DN/CR/PP/NN)',
                                        'HD+',
                                        'HD',
                                        'DN',
                                        'CR',
                                        'PP',
                                        'NN',

                                      ].map<DropdownMenuItem<String>>((
                                          String value) {
                                        return DropdownMenuItem<String>(
                                          value: value,
                                          child: Text(value, style: TextStyle(
                                              color: Colors.black),),
                                        );
                                      }).toList(),
                                      hint: Text(
                                        "Choose a Grade level",
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 15,
                                            fontWeight: FontWeight.w500),
                                      ),
                                      onChanged: (String value) {
                                        setState(() {
                                          _gradeWeek = value;
                                          print(_gradeWeek);
                                        });
                                      },
                                    ),

                                    actions: <Widget>[
                                      TextButton(
                                        onPressed: () =>
                                            Navigator.pop(context, 'Cancel'),
                                        child: const Text('Cancel'),
                                      ),
                                      new FlatButton(
                                        child: new Text("OK"),
                                        onPressed: () {
                                          if (_gradeWeek == "Choose a Grade Level (HD+/HD/DN/CR/PP/NN)") {
                                            _scaffoldKey.currentState.showSnackBar(
                                                SnackBar(
                                                  content: Text('Please choose a Grade Level (HD+/HD/DN/CR/PP/NN)'),
                                                )
                                            );
                                          }
                                          if (_gradeWeek == "HD+") {
                                            resultweek = 100;
                                            add(student.id);
                                          }
                                          if (_gradeWeek == "HD") {
                                            resultweek = 80;
                                            add(student.id);
                                          }
                                          if (_gradeWeek == "DN") {
                                            resultweek = 70;
                                            add(student.id);
                                          }
                                          if (_gradeWeek == "CR") {
                                            resultweek = 60;
                                            add(student.id);
                                          }
                                          if (_gradeWeek == "PP") {
                                            resultweek = 50;
                                            add(student.id);
                                          }
                                          if (_gradeWeek == "NN") {
                                            resultweek = 0;
                                            add(student.id);
                                          }
                                          Navigator.pop(context);
                                        },
                                      ),
                                    ],
                                  );
                                }
                                );
                              },
                            );
                            setState(() {
                              _gradeWeek="Choose a Grade Level (HD+/HD/DN/CR/PP/NN)";
                            });
                          }
                          if (widget.text == "Grade Level (A/B/C/D/E/F)") {
                            showDialog(
                              context: context,
                              builder: (BuildContext context) {
                               return StatefulBuilder(builder: (context,setState)
                               {
                                 return AlertDialog(

                                   title: new Text("SCORE"),

                                   content: DropdownButton<String>(
                                     focusColor: Colors.white,
                                     value: _gradesWeek,
                                     //elevation: 5,
                                     style: TextStyle(color: Colors.white),
                                     iconEnabledColor: Colors.black,
                                     items: <String>[
                                       'Choose a Grade Level (A/B/C/D/E/F)',
                                       'A',
                                       'B',
                                       'C',
                                       'D',
                                       'E',
                                       'F',

                                     ].map<DropdownMenuItem<String>>((
                                         String value) {
                                       return DropdownMenuItem<String>(
                                         value: value,
                                         child: Text(value, style: TextStyle(
                                             color: Colors.black),),
                                       );
                                     }).toList(),
                                     hint: Text(
                                       "Choose a Grade level",
                                       style: TextStyle(
                                           color: Colors.black,
                                           fontSize: 15,
                                           fontWeight: FontWeight.w500),
                                     ),
                                     onChanged: (String value) {
                                       setState(() {
                                         _gradesWeek = value;
                                         print(_gradesWeek);
                                       });
                                     },
                                   ),

                                   actions: <Widget>[
                                     TextButton(
                                       onPressed: () =>
                                           Navigator.pop(context, 'Cancel'),
                                       child: const Text('Cancel'),
                                     ),
                                     new FlatButton(
                                       child: new Text("OK"),
                                       onPressed: () {
                                         if (_gradesWeek == "Choose a Grade Level (A/B/C/D/E/F)") {
                                           _scaffoldKey.currentState.showSnackBar(
                                               SnackBar(
                                                 content: Text('Please choose a Grade Level (A/B/C/D/E/F)'),
                                               )
                                           );
                                         }
                                         if (_gradesWeek == "A") {
                                           resultweek = 100;
                                           add(student.id);
                                         }
                                         if (_gradesWeek == "B") {
                                           resultweek = 80;
                                           add(student.id);
                                         }
                                         if (_gradesWeek == "C") {
                                           resultweek = 70;
                                           add(student.id);
                                         }
                                         if (_gradesWeek == "D") {
                                           resultweek = 60;
                                           add(student.id);
                                         }
                                         if (_gradesWeek == "E") {
                                           resultweek = 50;
                                           add(student.id);
                                         }
                                         if (_gradesWeek == "F") {
                                           resultweek = 0;
                                           add(student.id);
                                         }
                                         Navigator.pop(context);
                                       },
                                     ),
                                   ],
                                 );
                               }
                               );
                              },
                            );
                            setState(() {
                              _gradesWeek="Choose a Grade Level (A/B/C/D/E/F)";
                            });
                          }
                          if (widget.text == "Attendance") {
                            showDialog(
                              context: context,
                              builder: (BuildContext context) {
                                return StatefulBuilder(builder: (context,setState)
                                {
                                  return AlertDialog(

                                    title: new Text("Select"),

                                    content: DropdownButton<String>(
                                      focusColor: Colors.white,
                                      value: _gradeAttendence,
                                      //elevation: 5,
                                      style: TextStyle(color: Colors.white),
                                      iconEnabledColor: Colors.black,
                                      items: <String>[
                                        'Attendance',
                                        'Present',
                                        'Absent',

                                      ].map<DropdownMenuItem<String>>((
                                          String value) {
                                        return DropdownMenuItem<String>(
                                          value: value,
                                          child: Text(value, style: TextStyle(
                                              color: Colors.black),),
                                        );
                                      }).toList(),
                                      hint: Text(
                                        "Choose Attendance",
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 15,
                                            fontWeight: FontWeight.w500),
                                      ),
                                      onChanged: (String value) {
                                        setState(() {
                                          _gradeAttendence = value;
                                          print(_gradeAttendence);
                                        });
                                      },
                                    ),

                                    actions: <Widget>[
                                      TextButton(
                                        onPressed: () =>
                                            Navigator.pop(context, 'Cancel'),
                                        child: const Text('Cancel'),
                                      ),
                                      new FlatButton(
                                        child: new Text("OK"),
                                        onPressed: () {
                                          if (_gradeAttendence == "Attendance") {
                                            _scaffoldKey.currentState.showSnackBar(
                                                SnackBar(
                                                  content: Text('Please choose Attendance'),
                                                )
                                            );
                                          }
                                          if (_gradeAttendence == "Present") {
                                            resultweek = 100;
                                            add(student.id);
                                          }
                                          if (_gradeAttendence == "Absent") {
                                            resultweek = 0;
                                            add(student.id);
                                          }

                                          Navigator.pop(context);
                                        },
                                      ),
                                    ],
                                  );
                                }
                                );
                              },
                            );
                            setState(() {
                              _gradeAttendence="Attendance";
                            });
                          }
                          if (widget.text == "Checkpoints") {
                            showDialog(
                              context: context,
                              builder: (BuildContext context) {
                                return StatefulBuilder(builder: (context,setState)
                                {
                                  return AlertDialog(

                                    title: new Text("Select"),

                                    content: DropdownButton<String>(
                                      focusColor: Colors.white,
                                      value: _gradeCheckpoints,
                                      //elevation: 5,
                                      style: TextStyle(color: Colors.white),
                                      iconEnabledColor: Colors.black,
                                      items: <String>[
                                        'Checkpoints',
                                        'Checkpoint-1',
                                        'Checkpoint-2',
                                        'Checkpoint-3',
                                        'Checkpoint-4',

                                      ].map<DropdownMenuItem<String>>((
                                          String value) {
                                        return DropdownMenuItem<String>(
                                          value: value,
                                          child: Text(value, style: TextStyle(
                                              color: Colors.black),),
                                        );
                                      }).toList(),
                                      hint: Text(
                                        "Choose Checkpoints",
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 15,
                                            fontWeight: FontWeight.w500),
                                      ),
                                      onChanged: (String value) {
                                        setState(() {
                                          _gradeCheckpoints = value;
                                          print(_gradeCheckpoints);
                                        });
                                      },
                                    ),

                                    actions: <Widget>[
                                      TextButton(
                                        onPressed: () =>
                                            Navigator.pop(context, 'Cancel'),
                                        child: const Text('Cancel'),
                                      ),
                                      new FlatButton(
                                        child: new Text("OK"),
                                        onPressed: () {
                                          if (_gradeCheckpoints == "Checkpoints") {
                                            _scaffoldKey.currentState.showSnackBar(
                                                SnackBar(
                                                  content: Text('Please choose Checkpoints'),
                                                )
                                            );
                                          }
                                          if (_gradeCheckpoints == "Checkpoint-1") {
                                            resultweek = 25;
                                            add(student.id);
                                          }
                                          if (_gradeCheckpoints == "Checkpoint-2") {
                                            resultweek = 50;
                                            add(student.id);
                                          }
                                          if (_gradeCheckpoints == "Checkpoint-3") {
                                            resultweek = 75;
                                            add(student.id);
                                          }
                                          if (_gradeCheckpoints == "Checkpoint-4") {
                                            resultweek = 100;
                                            add(student.id);
                                          }

                                          Navigator.pop(context);
                                        },
                                      ),
                                    ],
                                  );
                                }
                                );
                              },
                            );
                            setState(() {
                              _gradesWeek="Checkpoints";
                            });
                          }
                        }, icon: Icon(Icons.add), label: Text("ADD MARKS")),
                        onTap: () {

                        },

                      );
                    },
                    itemCount: studentModel.items.length


                ),

              ),

          ],
        ),
      ),
    );
  }


  Future<void> add(String id) async {
    log(" add $resultweek");
    //  log ("${student.Week02}");
    await studentsCollection.doc(id).update({'${widget.title}': resultweek
    });
    log("$id");
    Provider.of<StudentModel>(context, listen: false).fetch();
  }

  void _showSnackBar() {
    _scaffoldKey.currentState.showSnackBar(
        SnackBar(
          content: Text('Please enter score between 0 to 100'),
        )
    );
  }
}



class FullScreenText extends StatelessWidget {
  final String text;

  const FullScreenText({Key key, this.text}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Directionality(textDirection:TextDirection.ltr, child: Column(children: [ Expanded(child: Center(child: Text(text))) ]));
  }
}
