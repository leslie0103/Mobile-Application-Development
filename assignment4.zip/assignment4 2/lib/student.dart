import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class Student
{
  String id;
  String stdname;
  int stdid;
  int Week01 = 0;
  int Week02 = 0;
  int Week03 = 0;
  int Week04 = 0;
  int Week05 = 0;
  int Week06 = 0;
  int Week07 = 0;
  int Week08 = 0;
  int Week09 = 0;
  int Week10 = 0;
  String image;


  Student({ this.stdname, this.stdid, this.image});

  Student.fromJson(Map<String, dynamic> json)
      :
        stdname = json['Student Name'],
        stdid = json['Student ID'],
        Week01=json['Week01'],
  Week02=json['Week02'],
  Week03=json['Week03'],
  Week04=json['Week04'],
  Week05=json['Week05'],
  Week06=json['Week06'],
  Week07=json['Week07'],
        Week08=json['Week08'],
        Week09=json['Week09'],
        Week10=json['Week10']
  ;


  Map<String, dynamic> toJson() =>
      {
        'Student Name': stdname,
        'Student ID': stdid,
        'Week01':Week01,
        'Week02':Week02,
        'Week03':Week03,
        'Week04':Week04,
        'Week05':Week05,
        'Week06':Week06,
        'Week07':Week07,
        'Week08':Week08,
        'Week09':Week09,
        'Week10':Week10,

      };

}
class StudentModel extends ChangeNotifier {
  /// Internal, private state of the list.
  final List<Student> items = [];


  //Normally a model would get from a database here, we are just hardcoding some data for this week
  CollectionReference studentsCollection = FirebaseFirestore.instance.collection('students');
  bool loading = false;


  StudentModel()
  {
    fetch();
  }
  void fetch() async
  {
    //clear any existing data we have gotten previously, to avoid duplicate data
    items.clear();

    //indicate that we are loading
    loading = true;
    notifyListeners(); //tell children to redraw, and they will see that the loading indicator is on

    //get all movies
    var querySnapshot = await studentsCollection.orderBy("Student Name").get();

    //iterate over the movies and add them to the list
    querySnapshot.docs.forEach((doc) {
      //note not using the add(Movie item) function, because we don't want to add them to the db
      var student = Student.fromJson(doc.data());
      student.id = doc.id;
      items.add(student);
    });

    //put this line in to artificially increase the load time, so we can see the loading indicator (when we add it in a few steps time)
    //comment this out when the delay becomes annoying
    await Future.delayed(Duration(seconds: 2));

    //we're done, no longer loading
    loading = false;
    notifyListeners();
  }

  Student get(String id)
  {
    if (id == null) return null;
    return items.firstWhere((student) => student.id == id);
  }

  void add(Student item) async
  {
    loading = true;
    notifyListeners();

    await studentsCollection.add(item.toJson());

    //refresh the db
    await fetch();
  }

  void update(String id, Student item) async
  {
    loading = true;
    notifyListeners();

    await studentsCollection.doc(id).set(item.toJson());

    //refresh the db
    await fetch();
  }

  void delete(String id) async
  {
    loading = true;
    notifyListeners();

    await studentsCollection.doc(id).delete();

    //refresh the db
    await fetch();
  }
  /// Removes all items from the list.
  void removeAll() {
    items.clear();
    // This call tells the widgets that are listening to this model to rebuild.
    notifyListeners();
  }
}
