import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'student.dart';
class SummaryDetails extends StatefulWidget {

  final String id;



  const SummaryDetails({Key key, this.id}) : super(key: key);


  @override
  _SummaryDetailsState createState() => _SummaryDetailsState();
}

class _SummaryDetailsState extends State<SummaryDetails> {

int result;

double average;

  @override
  Widget build(BuildContext context) {
    var student = Provider.of<StudentModel>(context, listen:false).get(widget.id);
result=int.parse(student.Week01.toString())+int.parse(student.Week02.toString())+int.parse(student.Week03.toString())+int.parse(student.Week04.toString())+int.parse(student.Week05.toString())+int.parse(student.Week06.toString())+int.parse(student.Week07.toString())+int.parse(student.Week08.toString())+int.parse(student.Week09.toString())+int.parse(student.Week10.toString());
average= (result/10).roundToDouble();

print(result);
    return Scaffold(
        appBar: AppBar(
          title: Text("${student.stdname} Weekly Results"),
        ),
        body: Padding(
            padding: EdgeInsets.all(30),
            child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text("Student Name: ${student.stdname}",
                    style: TextStyle(
                      fontSize: 30.0,
                      fontWeight: FontWeight.w900,
                    ),),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text("Student ID: ${student.stdid}",

                      style: TextStyle(
                        fontSize: 18.0,
                        fontWeight: FontWeight.w500,
                      ),),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text("Week-1: ${student.Week01}",
                      style: TextStyle(
                        fontSize: 16.0,
                        fontWeight: FontWeight.w500,
                      ),),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text("Week-2: ${student.Week02}",
                      style: TextStyle(
                        fontSize: 16.0,
                        fontWeight: FontWeight.w500,
                      ),),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text("Week-3: ${student.Week03}",
                      style: TextStyle(
                        fontSize: 16.0,
                        fontWeight: FontWeight.w500,
                      ),),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text("Week-4: ${student.Week04}",
                      style: TextStyle(
                        fontSize: 16.0,
                        fontWeight: FontWeight.w500,
                      ),),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text("Week-5: ${student.Week05}",
                      style: TextStyle(
                        fontSize: 16.0,
                        fontWeight: FontWeight.w500,
                      ),),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text("Week-6: ${student.Week06}",
                      style: TextStyle(
                        fontSize: 16.0,
                        fontWeight: FontWeight.w500,
                      ),),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text("Week-7: ${student.Week07}",
                      style: TextStyle(
                        fontSize: 16.0,
                        fontWeight: FontWeight.w500,
                      ),),
                  ),

                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text("Week-8: ${student.Week08}",
                      style: TextStyle(
                        fontSize: 16.0,
                        fontWeight: FontWeight.w500,
                      ),),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text("Week-9: ${student.Week09}",
                      style: TextStyle(
                        fontSize: 16.0,
                        fontWeight: FontWeight.w500,
                      ),),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text("Week-10: ${student.Week10}",
                      style: TextStyle(
                        fontSize: 16.0,
                        fontWeight: FontWeight.w500,
                      ),),
                  ),

                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text("Average: $average",
                      style: TextStyle(
                        fontSize: 20.0,
                        fontWeight: FontWeight.w600,
                      ),),
                  ),



                ]
            )
        )
    );
  }

}