package com.example.assignment4

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
